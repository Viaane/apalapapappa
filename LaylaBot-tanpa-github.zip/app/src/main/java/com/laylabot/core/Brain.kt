package com.laylabot.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

class Output(
    /** Arah joystick, -1..1 (y positif = ke bawah). */
    val dirX: Float, val dirY: Float,
    val ult: Boolean,
    /** Non-null = bot harus berhenti (alasannya). */
    val stopReason: String?,
    val inGame: Boolean,
    val status: String
)

/** Menggabungkan Vision -> Tracker -> Planner -> keputusan ult / berhenti. */
class Brain(val cfg: Config) {
    val vision = Vision(cfg)
    val tracker = Tracker()
    val planner = Planner(cfg)

    /** Diisi dari OCR (Android). -1 = belum diketahui. */
    @Volatile var rawScore = -1
    /** Jumlah stack ult dari OCR. -1 = tidak diketahui. */
    @Volatile var ultStacks = -1

    var score = -1
        private set

    private var prevLayla: LaylaState? = null
    private var lastSeenMs = 0L
    private var prevDir = 0
    private var lastLives = -1
    private var defensiveUntil = 0L
    private var lastUltMs = 0L
    private var lastNow = 0L

    // kalibrasi kecepatan Layla
    private var calDir = 0
    private var calT = 0L
    private var calX = 0f
    private var calY = 0f

    var lastPlan: PlanResult? = null
        private set
    var lastPerception: Perception? = null
        private set

    fun reset() {
        tracker.reset(); prevLayla = null; prevDir = 0; lastLives = -1; score = -1
        lastSeenMs = 0; defensiveUntil = 0; lastUltMs = 0; calDir = 0
    }

    private fun acceptScore() {
        val r = rawScore
        if (r < 0) return
        // skor hanya naik, dan lompatannya wajar (kelipatan 10); tolak salah baca OCR
        if (score < 0 || (r >= score && r - score <= 600)) score = r
        else if (r < score && r <= 200) score = r          // run baru: skor kembali ke awal
    }

    fun step(f: Frame, nowMs: Long): Output {
        acceptScore()
        val p = vision.analyze(f, prevLayla)
        lastPerception = p
        var layla = p.layla
        val dt = if (lastNow == 0L) 0.05f else (nowMs - lastNow) / 1000f
        lastNow = nowMs

        if (layla != null) {
            lastSeenMs = nowMs
        } else if (prevLayla != null && nowMs - lastSeenMs < 400) {
            val pl = prevLayla!!      // dead reckoning singkat saat hati tertutup efek
            layla = LaylaState(
                (pl.cx + Planner.DX[prevDir] * planner.speed * dt).coerceIn(planner.xMin, planner.xMax),
                (pl.cy + Planner.DY[prevDir] * planner.speed * dt).coerceIn(planner.yMin, planner.yMax),
                pl.lives, false
            )
        }
        if (layla == null) {
            if (nowMs - lastSeenMs > 3000) score = -1       // keluar dari game: lupakan skor lama
            tracker.reset(); prevDir = 0
            return Output(0f, 0f, false, null, false, "Menunggu game…")
        }

        // target skor
        if (cfg.targetScore > 0 && score >= cfg.targetScore) {
            return Output(0f, 0f, false, "Target $score ≥ ${cfg.targetScore} tercapai", true, "Selesai")
        }

        if (layla.measured) {
            planner.observe(layla.cx, layla.cy)
            calibrate(layla, nowMs)
        }
        prevLayla = layla
        if (lastLives > 0 && layla.lives < lastLives) defensiveUntil = nowMs + 5000
        lastLives = layla.lives
        val defensive = nowMs < defensiveUntil

        // objek terlacak -> rintangan & buff
        val tracks = tracker.update(p.dets, nowMs)
        val obstacles = ArrayList<Obstacle>(tracks.size + 1)
        val buffs = ArrayList<BuffTarget>(2)
        for (t in tracks) {
            val vx = if (t.hasVel) t.vx else Tracker.priorVx(t.kind)
            if (t.kind == Kind.BUFF_GOLD || t.kind == Kind.BUFF_BLUE) {
                buffs += BuffTarget(t.x, t.y, vx)
            } else {
                obstacles += Obstacle(t.x, t.y, vx, t.vy, t.hw, t.hh, t.kind)
            }
        }
        var coreY: Float? = null
        val w = p.wall
        if (w != null) {
            val bodyW = 0.45f
            obstacles += Obstacle(w.frontX + bodyW / 2, 0.5f, -0.06f, 0f, bodyW / 2, 0.62f, null, true)
            if (w.hasCore && cfg.autoShootAlign) coreY = w.coreY
        }

        val plan = planner.plan(layla.cx, layla.cy, layla.lives, obstacles, buffs, coreY, prevDir, defensive)
        lastPlan = plan
        prevDir = plan.dirIndex

        // ult
        var ult = false
        if (cfg.useUlt && nowMs - lastUltMs > 1200 && ultStacks != 0) {
            val inFront = obstacles.count { !it.isWall && it.x > layla.cx && it.x < layla.cx + 0.9f && abs(it.y - layla.cy) < 0.45f }
            val emergency = plan.firstCollisionStep in 0..10
            val wallNear = w != null && w.frontX - layla.cx < 1.0f && (ultStacks > 0 || nowMs - lastUltMs > 3500)
            val crowd = inFront >= 5
            if (emergency || wallNear || crowd) { ult = true; lastUltMs = nowMs }
        }

        val status = buildString {
            append("HP ${layla.lives} · skor ${if (score >= 0) score else "?"}")
            if (cfg.targetScore > 0) append("/${cfg.targetScore}")
            append(" · objek ${obstacles.size}")
            if (w != null) append(" · TEMBOK")
            if (defensive) append(" · DEFENSIF")
        }
        return Output(Planner.DX[plan.dirIndex], Planner.DY[plan.dirIndex], ult, null, true, status)
    }

    /** Ukur kecepatan Layla sebenarnya dari perpindahan saat arah tetap, lalu perbarui planner. */
    private fun calibrate(l: LaylaState, now: Long) {
        if (prevDir != calDir) { calDir = prevDir; calT = now; calX = l.cx; calY = l.cy; return }
        if (calDir == 0) { calT = now; calX = l.cx; calY = l.cy; return }
        val el = (now - calT) / 1000f
        if (el < 0.4f) return
        val disp = hypot(l.cx - calX, l.cy - calY)
        val atEdge = l.cx <= planner.xMin + 0.01f || l.cx >= planner.xMax - 0.01f ||
            l.cy <= planner.yMin + 0.01f || l.cy >= planner.yMax - 0.01f
        if (!atEdge) {
            val meas = disp / max(0.1f, el - 0.1f)
            if (meas > 0.2f) planner.speed = (0.8f * planner.speed + 0.2f * meas).coerceIn(0.3f, 2.5f)
        } else if (disp < 0.01f) {
            // mentok: jadikan tepi baru
            if (Planner.DX[calDir] > 0.1f) planner.xMax = l.cx
            if (Planner.DX[calDir] < -0.1f) planner.xMin = l.cx
            if (Planner.DY[calDir] > 0.1f) planner.yMax = l.cy
            if (Planner.DY[calDir] < -0.1f) planner.yMin = l.cy
        }
        calT = now; calX = l.cx; calY = l.cy
    }
}
