package com.laylabot.core

/**
 * Satuan dunia: 1.0 = tinggi layar. x ke kanan, y ke bawah.
 * Semua posisi/ukuran dinormalisasi dengan tinggi frame, jadi tidak tergantung resolusi HP.
 */
enum class Kind { FIRE, ROCK, SHARD, BUFF_GOLD, BUFF_BLUE }

/** abgr = true bila piksel berformat RGBA_8888 dibaca sebagai Int little-endian (0xAABBGGRR), seperti ImageReader Android. */
class Frame(val w: Int, val h: Int, val px: IntArray, val abgr: Boolean = false)

data class Detection(
    val kind: Kind,
    val cx: Float, val cy: Float,   // pusat hitbox (bukan pusat sprite)
    val hw: Float, val hh: Float    // setengah lebar/tinggi hitbox
)

data class LaylaState(
    val cx: Float, val cy: Float,   // pusat badan
    val lives: Int,
    val measured: Boolean           // false = hasil dead-reckoning
)

data class WallState(val frontX: Float, val coreY: Float, val hasCore: Boolean)

class Perception(
    val aspect: Float,
    val dets: List<Detection>,
    val layla: LaylaState?,
    val wall: WallState?
)

/** Pengaturan yang bisa diubah user dari app. */
class Config {
    /** 0 = tanpa batas. Bot berhenti begitu skor >= nilai ini. */
    @Volatile var targetScore: Int = 1000
    /** Skala hitbox musuh terhadap bounding box yang terdeteksi. <1 = lebih berani, >1 = lebih aman. */
    @Volatile var hitScale: Float = 1.0f
    /** Seberapa menjauh dari bahaya (0.5..2). */
    @Volatile var caution: Float = 1.0f
    @Volatile var useUlt: Boolean = true
    @Volatile var pickBuffs: Boolean = true
    @Volatile var autoShootAlign: Boolean = true

    // Ukuran hurtbox Layla (satuan tinggi layar)
    var laylaHW = 0.060f
    var laylaHH = 0.070f
    /** Garis tembak berada sekian di bawah pusat badan. */
    var gunOffset = 0.051f
}
