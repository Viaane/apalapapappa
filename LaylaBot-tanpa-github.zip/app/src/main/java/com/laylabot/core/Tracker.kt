package com.laylabot.core

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class Track(val id: Int, val kind: Kind, var x: Float, var y: Float, var hw: Float, var hh: Float) {
    var vx = 0f
    var vy = 0f
    var age = 1
    var missed = 0
    var hasVel = false
}

/**
 * Pelacak sederhana: mencocokkan deteksi antar-frame (jenis sama, jarak terdekat) dan
 * menaksir kecepatan tiap objek. Kecepatan inilah yang dipakai planner untuk memprediksi lintasan.
 */
class Tracker {
    val tracks = ArrayList<Track>()
    private var nextId = 1
    private var lastT = 0L

    companion object {
        /** Kecepatan awal (satuan tinggi layar / detik) sebelum kecepatan terukur tersedia. */
        fun priorVx(k: Kind) = when (k) {
            Kind.FIRE -> -0.35f
            Kind.ROCK -> -0.22f
            Kind.SHARD -> -0.80f
            Kind.BUFF_GOLD, Kind.BUFF_BLUE -> -0.25f
        }
    }

    fun reset() { tracks.clear() }

    fun update(dets: List<Detection>, nowMs: Long): List<Track> {
        val dt = if (lastT == 0L) 0.05f else ((nowMs - lastT) / 1000f)
        lastT = nowMs
        if (dt > 0.4f || dt <= 0f) { tracks.clear() }

        val used = BooleanArray(dets.size)
        // pasangan (track, deteksi) terurut berdasar jarak
        data class Pair(val t: Int, val d: Int, val dist: Float)
        val pairs = ArrayList<Pair>()
        for (ti in tracks.indices) {
            val t = tracks[ti]
            val gate = 0.10f + 1.5f * hypot(t.vx, t.vy) * dt
            for (di in dets.indices) {
                val d = dets[di]
                if (d.kind != t.kind) continue
                val px = t.x + t.vx * dt; val py = t.y + t.vy * dt
                val dist = hypot(d.cx - px, d.cy - py)
                if (dist < gate) pairs += Pair(ti, di, dist)
            }
        }
        pairs.sortBy { it.dist }
        val matched = BooleanArray(tracks.size)
        for (p in pairs) {
            if (matched[p.t] || used[p.d]) continue
            matched[p.t] = true; used[p.d] = true
            val t = tracks[p.t]; val d = dets[p.d]
            if (dt in 0.01f..0.3f) {
                val nvx = (d.cx - t.x) / dt; val nvy = (d.cy - t.y) / dt
                if (!t.hasVel) { t.vx = nvx; t.vy = nvy; t.hasVel = true }
                else { t.vx += 0.4f * (nvx - t.vx); t.vy += 0.4f * (nvy - t.vy) }
                t.vx = t.vx.coerceIn(-1.6f, 0.3f); t.vy = t.vy.coerceIn(-0.9f, 0.9f)
            }
            t.x = d.cx; t.y = d.cy
            t.hw += 0.3f * (d.hw - t.hw); t.hh += 0.3f * (d.hh - t.hh)
            t.age++; t.missed = 0
        }
        // yang tidak cocok: coasting sebentar
        val it = tracks.iterator()
        var idx = 0
        while (it.hasNext()) {
            val t = it.next()
            if (!matched.getOrElse(idx) { true }) {
                t.missed++
                t.x += t.vx * dt; t.y += t.vy * dt
                if (t.missed > 3 || t.x < -0.4f) it.remove()
            }
            idx++
        }
        // deteksi baru
        for (di in dets.indices) {
            if (used[di]) continue
            val d = dets[di]
            val t = Track(nextId++, d.kind, d.cx, d.cy, d.hw, d.hh)
            t.vx = Tracker.priorVx(d.kind)
            tracks += t
        }
        return tracks
    }
}
