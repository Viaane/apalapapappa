package com.laylabot.core

import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Rintangan siap-prediksi (satuan tinggi layar). */
class Obstacle(
    val x: Float, val y: Float, val vx: Float, val vy: Float,
    val hw: Float, val hh: Float, val kind: Kind?, val isWall: Boolean = false
) {
    val shootable get() = kind == Kind.FIRE || kind == Kind.ROCK || kind == Kind.SHARD
}

class BuffTarget(val x: Float, val y: Float, val vx: Float)

class PlanResult(
    val dirIndex: Int,
    val cost: Float,
    /** Langkah (x0.05 dtk) tabrakan pertama pada rencana terbaik; -1 = rencana bebas tabrakan. */
    val firstCollisionStep: Int,
    val threats: Int
) {
    val collisionFree get() = firstCollisionStep < 0
}

/**
 * Planner prediksi multi-ancaman.
 *
 * Seluruh rintangan (atas, bawah, depan, sekaligus) diproyeksikan ke depan dengan kecepatan terukur.
 * Lalu dicoba semua rencana gerak 3 segmen (9 arah ^ 3 = 729 rencana) dan dipilih yang total biayanya
 * paling rendah: tabrakan, nyaris-tabrakan, terjepit di tepi/sudut, medan bahaya di ujung rencana,
 * dikurangi hadiah menembak sejajar, mengenai inti tembok, dan mengambil buff.
 * Karena yang dinilai adalah seluruh lintasan Layla terhadap seluruh rintangan, kasus 3-5 rintangan
 * datang bareng dari arah berbeda ditangani langsung, bukan satu per satu.
 */
class Planner(private val cfg: Config) {

    companion object {
        const val STEP = 0.05f
        const val STEPS = 24
        const val LAG_STEPS = 2                 // perintah yang sudah terkirim baru berefek ~0.1 dtk kemudian
        val SEG = intArrayOf(4, 6, 14)
        val DX = floatArrayOf(0f, 1f, 0.7071f, 0f, -0.7071f, -1f, -0.7071f, 0f, 0.7071f)
        val DY = floatArrayOf(0f, 0f, 0.7071f, 1f, 0.7071f, 0f, -0.7071f, -1f, -0.7071f)
        const val MAX_OBS = 16
    }

    /** Kecepatan Layla (tinggi layar / detik). Dikalibrasi online oleh Brain. */
    @Volatile var speed = 0.80f

    // Batas area gerak pusat badan Layla; diperbarui dari pengamatan.
    var xMin = 0.17f; var xMax = 0.62f
    var yMin = 0.17f; var yMax = 0.72f

    private val ox = FloatArray(MAX_OBS * (STEPS + 1))
    private val oy = FloatArray(MAX_OBS * (STEPS + 1))
    private val ohw = FloatArray(MAX_OBS)
    private val ohh = FloatArray(MAX_OBS)
    private val oShoot = BooleanArray(MAX_OBS)
    private val oWall = BooleanArray(MAX_OBS)

    fun observe(x: Float, y: Float) {
        if (x > xMax) xMax = x; if (x < xMin) xMin = x
        if (y > yMax) yMax = y; if (y < yMin) yMin = y
    }

    fun plan(
        lx: Float, ly: Float, lives: Int,
        obstaclesIn: List<Obstacle>, buffs: List<BuffTarget>,
        wallCoreY: Float?, prevDir: Int, defensive: Boolean
    ): PlanResult {
        val L = cfg
        // pilih rintangan paling relevan (dekat di x, tidak jauh di belakang)
        val obs = obstaclesIn.asSequence()
            .filter { it.x - it.hw < lx + 1.7f && it.x + it.hw > lx - 0.35f }
            .sortedBy { abs(it.x - lx) + 0.35f * abs(it.y - ly) }
            .take(MAX_OBS).toList()
        val n = obs.size
        for (i in 0 until n) {
            val o = obs[i]
            ohw[i] = o.hw * L.hitScale + L.laylaHW
            ohh[i] = o.hh * L.hitScale + L.laylaHH
            oShoot[i] = o.shootable
            oWall[i] = o.isWall
            for (k in 0..STEPS) {
                val t = k * STEP
                ox[i * (STEPS + 1) + k] = o.x + o.vx * t
                oy[i * (STEPS + 1) + k] = o.y + o.vy * t
            }
        }

        val caution = L.caution * (if (defensive) 1.5f else 1f)
        val margin = 0.045f * caution
        val colW = 300f * (if (lives <= 1) 1.8f else if (defensive) 1.3f else 1f)
        val shootW = if (defensive) 1.2f else 3.0f
        val v = speed * STEP

        var bestCost = Float.MAX_VALUE
        var bestDir = 0
        var bestCol = -1

        val a = IntArray(3)
        for (d1 in 0..8) for (d2 in 0..8) for (d3 in 0..8) {
            a[0] = d1; a[1] = d2; a[2] = d3
            var px = lx; var py = ly
            var cost = 0f
            var firstCol = -1
            var buffGot = false
            var k = 0
            // segmen: pertama LAG_STEPS langkah masih memakai perintah lama (prevDir)
            var seg = 0
            var segLeft = SEG[0]
            var curDir = d1
            while (k < STEPS) {
                val dir = if (k < LAG_STEPS) prevDir else curDir
                px = (px + DX[dir] * v).coerceIn(xMin, xMax)
                py = (py + DY[dir] * v).coerceIn(yMin, yMax)
                k++
                val tw = 1f - 0.5f * k / STEPS
                val gunY = py + L.gunOffset
                for (i in 0 until n) {
                    val idx = i * (STEPS + 1) + k
                    val dx = abs(px - ox[idx]); val dy = abs(py - oy[idx])
                    val gx = dx - ohw[i]; val gy = dy - ohh[i]
                    if (gx < 0f && gy < 0f) {
                        if (firstCol < 0) firstCol = k
                        cost += colW * tw
                    } else {
                        val dist = hypot(max(gx, 0f), max(gy, 0f))
                        if (dist < margin) {
                            val f = 1f - dist / margin
                            cost += 3f * f * f * tw
                        }
                    }
                    // hadiah menembak: sejajar dan musuh di depan
                    if (oShoot[i] && ox[idx] > px && ox[idx] < 2.2f && abs(gunY - oy[idx]) < ohh[i] - L.laylaHH + 0.02f) {
                        val prio = (1f / (0.4f + (ox[idx] - px))).coerceIn(0.5f, 2.5f)
                        cost -= shootW * prio * STEP
                    }
                }
                if (wallCoreY != null && abs(gunY - wallCoreY) < 0.045f) cost -= 8f * STEP
                if (!buffGot && L.pickBuffs) {
                    for (b in buffs) {
                        val bx = b.x + b.vx * k * STEP
                        if (abs(px - bx) < 0.08f && abs(py - b.y) < 0.08f) { buffGot = true; cost -= 12f; break }
                    }
                }
                // ganti segmen
                segLeft--
                if (segLeft == 0 && seg < 2) {
                    seg++; segLeft = SEG[seg]; curDir = a[seg]
                    if (a[seg] != a[seg - 1]) cost += 0.3f
                }
            }
            // medan bahaya di ujung rencana (lihat ke depan: jangan berakhir di tengah gerombolan)
            val kEnd = STEPS
            for (i in 0 until n) {
                val idx = i * (STEPS + 1) + kEnd
                val gx = max(abs(px - ox[idx]) - ohw[i], 0f); val gy = max(abs(py - oy[idx]) - ohh[i], 0f)
                cost += 6f * caution * exp(-hypot(gx, gy) / 0.10f)
            }
            // tepi & sudut
            val ex = min(px - xMin, xMax - px); val ey = min(py - yMin, yMax - py)
            if (ex < 0.04f) cost += 3f * (1f - ex / 0.04f)
            if (ey < 0.04f) cost += 3f * (1f - ey / 0.04f)
            if (ex < 0.04f && ey < 0.04f) cost += 5f
            // preferensi halus: dekat tepi kiri-tengah memberi waktu reaksi
            cost += 2f * (px - (xMin + 0.10f)) * (px - (xMin + 0.10f))
            cost += 0.8f * (py - 0.45f) * (py - 0.45f)
            // kehalusan
            if (d1 != prevDir) cost += 0.8f
            if (d1 != 0) cost += 0.03f

            if (cost < bestCost) {
                bestCost = cost; bestDir = d1; bestCol = firstCol
            }
        }
        return PlanResult(bestDir, bestCost, bestCol, n)
    }
}
