package com.laylabot.core

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Deteksi berbasis warna (tanpa model ML). Frame di-subsample ke grid ~640 kolom,
 * tiap sel diberi bit warna, lalu komponen terhubung dicari per kelas.
 */
class Vision(private val cfg: Config) {

    companion object {
        const val F_ORANGE = 1
        const val F_MAG = 2
        const val F_CYAN = 4
        const val F_PASTEL = 8
        const val F_PALEBLUE = 16
        const val F_DARK = 32
        const val TARGET_COLS = 640
    }

    class Comp(var minX: Int, var minY: Int, var maxX: Int, var maxY: Int, var count: Int) {
        val w get() = maxX - minX + 1
        val h get() = maxY - minY + 1
    }

    private var gw = 0
    private var gh = 0
    private var step = 1
    private var flags = ByteArray(0)
    private var tmp = IntArray(0)
    private var dil = BooleanArray(0)
    private var labels = IntArray(0)
    private var stack = IntArray(0)

    /** Debug: komponen mentah terakhir (grid) untuk visualisasi. */
    var lastHearts: List<Comp> = emptyList()
    var debugDark = false

    fun analyze(f: Frame, prev: LaylaState?): Perception {
        step = max(1, f.w / TARGET_COLS)
        gw = f.w / step
        gh = f.h / step
        val n = gw * gh
        if (flags.size != n) {
            flags = ByteArray(n); tmp = IntArray(n + 1); dil = BooleanArray(n)
            labels = IntArray(n); stack = IntArray(n)
        }
        classify(f)
        maskUi()

        val cellToWorld = step.toFloat() / f.h          // 1 sel grid -> satuan dunia
        val aspect = f.w.toFloat() / f.h
        val dets = ArrayList<Detection>(24)

        var wall: WallState? = null

        // ---- MAGMA WALL: komponen oranye (garis emas) setinggi layar; inti = baris oranye terpadat ----
        for (c in components(F_ORANGE, 3, 30)) {
            if (c.h >= 0.45f * gh) { wall = buildWall(c, cellToWorld); break }
        }
        val dark = components(F_DARK, 2, 14)
        if (wall == null) {
            for (c in dark) if (c.h >= 0.45f * gh) { wall = WallState(c.minX * cellToWorld, 0.5f, false); break }
        }
        val wallLo = wall?.let { it.frontX - 0.05f }
        val wallHi = wall?.let { it.frontX + 0.55f }

        // ---- BLOB GELAP: badan meteor/batu/serpihan. Warna di dalamnya menentukan jenisnya. ----
        val solid = ArrayList<IntArray>()   // bbox grid blob gelap, untuk menyaring orb/bubble
        for (c in dark) {
            if (c.h >= 0.45f * gh) continue
            val fill = c.count.toFloat() / (c.w * c.h)
            if (c.count < 60 || fill < 0.12f) continue          // cincin tipis = orb buff, bukan musuh
            if ((c.minY == 0 || c.maxY == gh - 1) && c.h < 20) continue   // serpihan sempit di tepi layar
            val ccx = (c.minX + c.maxX + 1) / 2f * cellToWorld
            if (wallLo != null && ccx >= wallLo && ccx <= wallHi!!) continue   // serpihan tembok
            val pad = 3
            val x0 = max(0, c.minX - pad); val x1 = min(gw - 1, c.maxX + pad)
            val y0 = max(0, c.minY - pad); val y1 = min(gh - 1, c.maxY + pad)
            var o = 0; var m = 0; var cy = 0
            for (y in y0..y1) for (x in x0..x1) {
                val fl = flags[y * gw + x].toInt()
                if (fl and F_ORANGE != 0) o++
                if (fl and F_MAG != 0) m++
                if (fl and F_CYAN != 0) cy++
            }
            if (debugDark) println("dark x=%d..%d y=%d..%d count=%d fill=%.2f o=%d m=%d c=%d".format(c.minX, c.maxX, c.minY, c.maxY, c.count, fill, o, m, cy))
            val kind = when {
                m >= 6 && m >= o -> Kind.ROCK
                o >= 6 -> Kind.FIRE
                cy >= 4 -> Kind.SHARD
                else -> null
            } ?: continue
            solid += intArrayOf(c.minX, c.minY, c.maxX, c.maxY)
            val minX = c.minX.toFloat(); var maxX = c.maxX + 1f
            if (kind == Kind.FIRE) maxX += 0.15f * c.w      // sedikit ekor api ikut jadi hitbox
            dets += Detection(
                kind,
                (minX + maxX) / 2f * cellToWorld, (c.minY + c.maxY + 1) / 2f * cellToWorld,
                (maxX - minX) / 2f * cellToWorld, c.h / 2f * cellToWorld
            )
        }

        fun nearSolid(c: Comp, m: Int = 10): Boolean {
            val cx = (c.minX + c.maxX) / 2; val cy = (c.minY + c.maxY) / 2
            for (b in solid) if (cx >= b[0] - m && cx <= b[2] + m && cy >= b[1] - m && cy <= b[3] + m) return true
            return false
        }

        // ---- ORB EMAS (buff): bulat, tanpa badan gelap ----
        for (c in components(F_ORANGE, 4, 20)) {
            if (c.h >= 0.45f * gh || nearSolid(c)) continue
            val asp = c.w.toFloat() / c.h
            val wNorm = c.w.toFloat() / gw
            if (asp in 0.75f..1.33f && wNorm in 0.03f..0.07f) {
                dets += Detection(
                    Kind.BUFF_GOLD,
                    (c.minX + c.maxX + 1) / 2f * cellToWorld, (c.minY + c.maxY + 1) / 2f * cellToWorld,
                    c.w / 2f * cellToWorld, c.h / 2f * cellToWorld
                )
            }
        }

        // ---- BUBBLE BIRU (buff) ----
        for (c in components(F_PALEBLUE, 2, 12)) {
            if (nearSolid(c, 22)) continue
            val wN = c.w.toFloat() / gw
            val asp = c.w.toFloat() / c.h
            if (wN in 0.03f..0.07f && asp in 0.8f..1.25f) {
                dets += Detection(
                    Kind.BUFF_BLUE,
                    (c.minX + c.maxX + 1) / 2f * cellToWorld, (c.minY + c.maxY + 1) / 2f * cellToWorld,
                    c.w * 0.5f * cellToWorld, c.h * 0.5f * cellToWorld
                )
            }
        }

        val layla = findLayla(f, cellToWorld, prev)
        return Perception(aspect, dets, layla, wall)
    }

    // ------------------------------------------------------------------ klasifikasi warna

    private fun classify(f: Frame) {
        val px = f.px
        var o = 0
        for (gy in 0 until gh) {
            val rowBase = gy * step * f.w
            for (gx in 0 until gw) {
                val p = px[rowBase + gx * step]
                val g = (p shr 8) and 255
                val r = if (f.abgr) p and 255 else (p shr 16) and 255
                val b = if (f.abgr) (p shr 16) and 255 else p and 255
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                var fl = 0
                if (mx < 95) fl = fl or F_DARK
                if (mx >= 150) {
                    val d = mx - mn
                    val s = if (mx == 0) 0 else d * 255 / mx
                    var h = 0
                    if (d != 0) {
                        h = when (mx) {
                            r -> 30 * (g - b) / d
                            g -> 60 + 30 * (b - r) / d
                            else -> 120 + 30 * (r - g) / d
                        }
                        if (h < 0) h += 180
                    }
                    if (h in 4..24 && s >= 140 && mx >= 170) fl = fl or F_ORANGE
                    if (h in 136..168 && s >= 110) fl = fl or F_MAG
                    if (h in 88..108 && s in 60..200 && mx >= 215) fl = fl or F_CYAN
                    if (h in 130..170 && s in 40..130 && mx >= 225) fl = fl or F_PASTEL
                    if (h in 100..125 && s in 20..110 && mx >= 235) fl = fl or F_PALEBLUE
                }
                flags[o++] = fl.toByte()
            }
        }
    }

    /** Hapus UI statis: tombol ult, joystick, HUD kanan atas. */
    private fun maskUi() {
        fun circle(cxN: Float, cyN: Float, rN: Float) {
            val cx = cxN * gw; val cy = cyN * gh; val r = rN * gw
            val y0 = max(0, (cy - r).toInt()); val y1 = min(gh - 1, (cy + r).toInt())
            val x0 = max(0, (cx - r).toInt()); val x1 = min(gw - 1, (cx + r).toInt())
            for (y in y0..y1) for (x in x0..x1) {
                val dx = x - cx; val dy = y - cy
                if (dx * dx + dy * dy <= r * r) flags[y * gw + x] = 0
            }
        }
        circle(0.883f, 0.807f, 0.062f)   // ult
        circle(0.1226f, 0.790f, 0.075f)  // joystick
        val hx = (0.55f * gw).toInt(); val hy = (0.19f * gh).toInt()
        for (y in 0 until hy) for (x in hx until gw) flags[y * gw + x] = 0
    }

    // ------------------------------------------------------------------ komponen terhubung

    private fun components(bit: Int, dilate: Int, minCells: Int): List<Comp> {
        val b = bit.toByte().toInt()
        // dilasi horizontal (prefix sum) lalu vertikal
        for (y in 0 until gh) {
            var acc = 0
            val base = y * gw
            tmp[0] = 0
            for (x in 0 until gw) { acc += if ((flags[base + x].toInt() and b) != 0) 1 else 0; tmp[x + 1] = acc }
            for (x in 0 until gw) {
                val lo = max(0, x - dilate); val hi = min(gw - 1, x + dilate)
                dil[base + x] = tmp[hi + 1] - tmp[lo] > 0
            }
        }
        // vertikal: simpan hasil di labels sementara sebagai 0/1
        for (x in 0 until gw) {
            var acc = 0
            tmp[0] = 0
            for (y in 0 until gh) { acc += if (dil[y * gw + x]) 1 else 0; tmp[y + 1] = acc }
            for (y in 0 until gh) {
                val lo = max(0, y - dilate); val hi = min(gh - 1, y + dilate)
                labels[y * gw + x] = if (tmp[hi + 1] - tmp[lo] > 0) -1 else -2   // -1 = belum dikunjungi, -2 = kosong
            }
        }
        val out = ArrayList<Comp>()
        for (start in 0 until gw * gh) {
            if (labels[start] != -1) continue
            var sp = 0
            stack[sp++] = start; labels[start] = 1
            val c = Comp(Int.MAX_VALUE, Int.MAX_VALUE, -1, -1, 0)
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % gw; val y = i / gw
                if ((flags[i].toInt() and b) != 0) {
                    if (x < c.minX) c.minX = x; if (x > c.maxX) c.maxX = x
                    if (y < c.minY) c.minY = y; if (y > c.maxY) c.maxY = y
                    c.count++
                }
                if (x > 0 && labels[i - 1] == -1) { labels[i - 1] = 1; stack[sp++] = i - 1 }
                if (x < gw - 1 && labels[i + 1] == -1) { labels[i + 1] = 1; stack[sp++] = i + 1 }
                if (y > 0 && labels[i - gw] == -1) { labels[i - gw] = 1; stack[sp++] = i - gw }
                if (y < gh - 1 && labels[i + gw] == -1) { labels[i + gw] = 1; stack[sp++] = i + gw }
            }
            if (c.count >= minCells && c.maxX >= 0) out += c
        }
        return out
    }

    // ------------------------------------------------------------------ Magma Wall

    private fun buildWall(c: Comp, cw: Float): WallState {
        // inti = baris dengan sel oranye terbanyak di sekitar tepi kiri tembok
        val x0 = c.minX
        val x1 = min(gw - 1, c.minX + (0.12f * gw).toInt())
        val rows = IntArray(gh)
        val orange = F_ORANGE.toByte().toInt()
        for (y in c.minY..c.maxY) {
            var k = 0
            for (x in x0..x1) if ((flags[y * gw + x].toInt() and orange) != 0) k++
            rows[y] = k
        }
        val win = max(3, gh / 24)
        var best = -1; var bestSum = 0
        var sum = 0
        for (y in c.minY..c.maxY) {
            sum += rows[y]
            if (y - win >= c.minY) sum -= rows[y - win]
            if (sum > bestSum) { bestSum = sum; best = y - win / 2 }
        }
        val sorted = rows.sliceArray(c.minY..c.maxY).sorted()
        val median = sorted[sorted.size / 2].coerceAtLeast(1)
        val hasCore = best >= 0 && bestSum.toFloat() / win >= 3.5f * median
        val coreY = if (hasCore) (best + 0.5f) * cw else (c.minY + c.maxY + 1) / 2f * cw
        return WallState(c.minX * cw, coreY, hasCore)
    }

    // ------------------------------------------------------------------ Layla via hati (nyawa)

    /**
     * Hati nyawa selalu melayang tetap di atas Layla (offset konstan), jadi dipakai sebagai jangkar posisi
     * sekaligus penghitung nyawa. Peluru juga merah muda tapi tipis, jadi disaring lewat aspek rasio.
     */
    private fun findLayla(f: Frame, cw: Float, prev: LaylaState?): LaylaState? {
        val hearts = components(F_PASTEL, 1, 6).filter {
            val wN = it.w.toFloat() / gw
            val asp = it.w.toFloat() / it.h
            wN in 0.008f..0.026f && asp in 0.7f..1.6f && it.h >= 5
        }
        lastHearts = hearts
        if (hearts.isEmpty()) return null

        // kelompokkan berdasar baris (y mirip)
        val rows = hearts.groupBy { (it.minY + it.maxY) / 2 / max(1, gh / 40) }.values
        val pitch = 0.0245f * gw
        var bestGroup: List<Comp>? = null
        var bestScore = Float.MAX_VALUE
        for (g in rows) {
            val sorted = g.sortedBy { it.minX }
            // validasi jarak antar hati ~ pitch
            var ok = true
            for (i in 1 until sorted.size) {
                val d = (sorted[i].minX + sorted[i].maxX) / 2f - (sorted[i - 1].minX + sorted[i - 1].maxX) / 2f
                if (abs(d - pitch) > 0.5f * pitch) ok = false
            }
            if (!ok) continue
            val cxPix = (sorted[0].minX + sorted[0].maxX) / 2f
            val cyPix = (sorted[0].minY + sorted[0].maxY) / 2f
            if (cxPix > 0.75f * gw) continue
            val sc = if (prev != null) abs(cxPix * cw - prev.cx) + abs(cyPix * cw - (prev.cy - 0.141f)) else cxPix
            if (sc < bestScore) { bestScore = sc; bestGroup = sorted }
        }
        val g = bestGroup ?: return null
        val first = g[0]
        val heartsX = (first.minX + first.maxX + 1) / 2f + pitch + 0.01f * (f.w.toFloat() / step)
        val heartsY = (first.minY + first.maxY + 1) / 2f
        val cx = heartsX * cw
        val cy = heartsY * cw + 0.141f
        return LaylaState(cx, cy, g.size.coerceIn(1, 3), true)
    }
}
