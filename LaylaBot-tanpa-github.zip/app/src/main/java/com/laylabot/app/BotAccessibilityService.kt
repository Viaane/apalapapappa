package com.laylabot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * Menggeser joystick virtual dengan satu jari yang terus menempel (stroke bersambung),
 * dan menekan tombol ult dengan jari kedua. Posisi kontrol berupa pecahan layar,
 * dikalibrasi dari screenshot game (2576x1189).
 */
class BotAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotAccessibilityService? = null

        const val JOY_X = 0.1226f     // pusat joystick (pecahan lebar)
        const val JOY_Y = 0.810f      // pusat joystick (pecahan tinggi)
        const val JOY_R = 0.040f      // jarak geser penuh (pecahan lebar)
        const val ULT_X = 0.883f
        const val ULT_Y = 0.807f
        const val SEGMENT_MS = 50L
    }

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var tx = 0f
    @Volatile private var ty = 0f
    @Volatile private var wantUlt = false
    private var inFlight = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var lastX = 0f
    private var lastY = 0f

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun setJoystick(dx: Float, dy: Float) { tx = dx; ty = dy; main.post { pump() } }
    fun tapUlt() { wantUlt = true; main.post { pump() } }
    fun release() { tx = 0f; ty = 0f; main.post { pump() } }

    private fun pump() {
        if (inFlight) return
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat(); val h = dm.heightPixels.toFloat()
        val cx = JOY_X * w; val cy = JOY_Y * h; val r = JOY_R * w
        val moving = tx != 0f || ty != 0f
        val active = stroke != null
        if (!moving && !active && !wantUlt) return

        val gb = GestureDescription.Builder()
        if (moving || active) {
            val px = if (moving) cx + tx * r else cx
            val py = if (moving) cy + ty * r else cy
            val path = Path()
            val st: GestureDescription.StrokeDescription
            if (!active) {
                path.moveTo(cx, cy); path.lineTo(px, py)
                st = GestureDescription.StrokeDescription(path, 0, SEGMENT_MS, moving)
            } else {
                path.moveTo(lastX, lastY)
                if (abs(px - lastX) > 1f || abs(py - lastY) > 1f) path.lineTo(px, py)
                st = stroke!!.continueStroke(path, 0, SEGMENT_MS, moving)
            }
            gb.addStroke(st)
            stroke = if (moving) st else null
            lastX = px; lastY = py
        }
        if (wantUlt) {
            val p = Path(); p.moveTo(ULT_X * w, ULT_Y * h)
            gb.addStroke(GestureDescription.StrokeDescription(p, 0, 40, false))
            wantUlt = false
        }
        inFlight = true
        val ok = dispatchGesture(gb.build(), object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { inFlight = false; pump() }
            override fun onCancelled(g: GestureDescription?) { inFlight = false; stroke = null; pump() }
        }, main)
        if (!ok) { inFlight = false; stroke = null }
    }
}
