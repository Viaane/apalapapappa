package com.laylabot.app

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/** Pil kecil di tengah bawah layar: menampilkan status, ketuk untuk jeda/lanjut. */
class Overlay(private val ctx: Context, private val onToggle: () -> Unit) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: TextView? = null

    fun show() {
        if (!Settings.canDrawOverlays(ctx)) return
        val tv = TextView(ctx).apply {
            text = "Layla Bot"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(24, 6, 24, 6)
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { onToggle() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 4 }
        wm.addView(tv, lp)
        view = tv
    }

    fun setText(s: String) { view?.post { view?.text = s } }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
