package com.laylabot.app

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.laylabot.core.Brain
import com.laylabot.core.Frame
import java.util.concurrent.atomic.AtomicBoolean

/** Membaca "Poin Saat Ini: NNNN" dan stack ult "n/m" dari layar, sekitar 2x per detik. */
class ScoreOcr(private val brain: Brain) {
    private val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val busy = AtomicBoolean(false)
    private var lastMs = 0L

    fun maybeRun(f: Frame, now: Long) {
        if (now - lastMs < 450 || !busy.compareAndSet(false, true)) return
        lastMs = now
        val score = crop(f, 0.80f, 0.04f, 0.905f, 0.13f)
        val ult = crop(f, 0.85f, 0.84f, 0.92f, 0.89f)
        rec.process(InputImage.fromBitmap(score, 0))
            .addOnSuccessListener { t ->
                val m = Regex("\\d{2,5}").findAll(t.text).lastOrNull()
                val v = m?.value?.toIntOrNull()
                if (v != null && v % 10 == 0) brain.rawScore = v
            }
            .addOnCompleteListener {
                rec.process(InputImage.fromBitmap(ult, 0))
                    .addOnSuccessListener { t ->
                        val m = Regex("(\\d)\\s*/\\s*(\\d)").find(t.text)
                        brain.ultStacks = m?.groupValues?.get(1)?.toIntOrNull() ?: -1
                    }
                    .addOnCompleteListener { busy.set(false) }
            }
    }

    private fun crop(f: Frame, x0: Float, y0: Float, x1: Float, y1: Float): Bitmap {
        val ax = (x0 * f.w).toInt(); val ay = (y0 * f.h).toInt()
        val w = ((x1 - x0) * f.w).toInt(); val h = ((y1 - y0) * f.h).toInt()
        val out = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val p = f.px[(ay + y) * f.w + ax + x]
            // ABGR (RGBA_8888 little-endian) -> ARGB
            out[y * w + x] = if (f.abgr) (p and 0xFF00FF00.toInt()) or ((p and 0xFF) shl 16) or ((p shr 16) and 0xFF) else p
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}
