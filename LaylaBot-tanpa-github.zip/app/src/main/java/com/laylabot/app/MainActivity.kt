package com.laylabot.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.os.Bundle
import android.text.InputType
import com.laylabot.core.Config

class MainActivity : Activity() {

    private val REQ_CAPTURE = 100
    private lateinit var status: TextView
    private lateinit var target: EditText
    private lateinit var cautionBar: SeekBar
    private lateinit var hitBar: SeekBar
    private lateinit var cautionLabel: TextView
    private lateinit var hitLabel: TextView
    private lateinit var ult: Switch
    private lateinit var buff: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val cfg = Config(); Prefs.load(this, cfg)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        fun tv(t: String, size: Float = 14f, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD); setPadding(0, 12, 0, 4)
        }
        fun btn(t: String, click: () -> Unit) = Button(this).apply { text = t; setOnClickListener { click() } }

        root.addView(tv("Layla Bot · Starfall Breakout", 22f, true))
        root.addView(tv("Bot mendeteksi meteor/rintangan lewat tangkapan layar, memprediksi lintasannya, lalu menggeser joystick dan menekan ult otomatis."))

        root.addView(tv("Berhenti otomatis di skor (0 = tanpa batas)", 14f, true))
        target = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(cfg.targetScore.toString()) }
        root.addView(target)

        cautionLabel = tv("")
        cautionBar = SeekBar(this).apply {
            max = 150; progress = ((cfg.caution - 0.5f) * 100).toInt()
            setOnSeekBarChangeListener(simple { cautionLabel.text = "Kehati-hatian: %.2f (lebih besar = menjauh lebih lebar)".format(0.5f + it / 100f) })
        }
        cautionLabel.text = "Kehati-hatian: %.2f (lebih besar = menjauh lebih lebar)".format(cfg.caution)
        root.addView(cautionLabel); root.addView(cautionBar)

        hitLabel = tv("")
        hitBar = SeekBar(this).apply {
            max = 60; progress = ((cfg.hitScale - 0.7f) * 100).toInt()
            setOnSeekBarChangeListener(simple { hitLabel.text = "Skala hitbox musuh: %.2f".format(0.7f + it / 100f) })
        }
        hitLabel.text = "Skala hitbox musuh: %.2f".format(cfg.hitScale)
        root.addView(hitLabel); root.addView(hitBar)

        ult = Switch(this).apply { text = "Pakai ult saat darurat / lawan tembok"; isChecked = cfg.useUlt }
        buff = Switch(this).apply { text = "Ambil buff (bola kuning & bubble biru)"; isChecked = cfg.pickBuffs }
        root.addView(ult); root.addView(buff)

        root.addView(tv("Langkah", 16f, true))
        root.addView(btn("1. Aktifkan Accessibility “Layla Bot”") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("2. Izinkan tampil di atas app lain") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("3. MULAI BOT") { start() })
        root.addView(btn("Stop") {
            startService(Intent(this, BotService::class.java).setAction(BotService.ACTION_STOP))
        })

        status = tv("", 13f)
        root.addView(status)
        root.addView(tv("Cara pakai: tekan MULAI, setujui rekam layar, buka MLBB, masuk ke Starfall Breakout dan mulai run. Bot menunggu sampai Layla terdeteksi. Ketuk pil “Layla Bot” di bawah layar untuk jeda/lanjut.", 12f))

        setContentView(ScrollView(this).apply { addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT) })
    }

    private fun simple(on: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = on(p)
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    private fun accessibilityOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun refreshStatus() {
        status.text = buildString {
            append("Accessibility: ${if (accessibilityOn()) "AKTIF ✓" else "belum aktif ✗"}\n")
            append("Overlay: ${if (Settings.canDrawOverlays(this@MainActivity)) "diizinkan ✓" else "belum ✗"}\n")
            append("Bot: ${if (BotService.running) "BERJALAN" else "berhenti"}")
            if (BotService.lastMessage.isNotEmpty()) append("\nTerakhir: ${BotService.lastMessage}")
        }
    }

    private fun start() {
        if (!accessibilityOn()) { Toast.makeText(this, "Aktifkan Accessibility dulu (langkah 1)", Toast.LENGTH_LONG).show(); return }
        if (!Settings.canDrawOverlays(this)) { Toast.makeText(this, "Izinkan overlay dulu (langkah 2)", Toast.LENGTH_LONG).show(); return }
        val t = target.text.toString().toIntOrNull() ?: 0
        Prefs.save(this, t, 0.5f + cautionBar.progress / 100f, 0.7f + hitBar.progress / 100f, ult.isChecked, buff.isChecked)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        BotService.lastMessage = ""
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, BotService::class.java).putExtra("code", resultCode).putExtra("data", data))
            Toast.makeText(this, "Bot jalan. Buka game sekarang.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        }
    }
}
