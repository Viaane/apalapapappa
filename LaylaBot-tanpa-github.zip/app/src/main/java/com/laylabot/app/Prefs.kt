package com.laylabot.app

import android.content.Context
import com.laylabot.core.Config

/** Penyimpanan pengaturan user. */
object Prefs {
    private const val FILE = "laylabot"

    fun load(ctx: Context, cfg: Config) {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        cfg.targetScore = p.getInt("target", 1000)
        cfg.caution = p.getFloat("caution", 1.0f)
        cfg.hitScale = p.getFloat("hitScale", 1.0f)
        cfg.useUlt = p.getBoolean("ult", true)
        cfg.pickBuffs = p.getBoolean("buff", true)
    }

    fun save(ctx: Context, target: Int, caution: Float, hitScale: Float, ult: Boolean, buff: Boolean) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit()
            .putInt("target", target).putFloat("caution", caution).putFloat("hitScale", hitScale)
            .putBoolean("ult", ult).putBoolean("buff", buff).apply()
    }
}
