package com.laylabot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import com.laylabot.core.Brain
import com.laylabot.core.Config
import com.laylabot.core.Frame
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** Foreground service: tangkap layar -> Brain -> kirim gerakan lewat AccessibilityService. */
class BotService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var lastMessage = ""
        const val CH = "laylabot"
        const val ACTION_STOP = "com.laylabot.STOP"
    }

    private val cfg = Config()
    private lateinit var brain: Brain
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var overlay: Overlay? = null
    private var ocr: ScoreOcr? = null
    @Volatile private var paused = false
    private var px = IntArray(0)
    private var capW = 0
    private var capH = 0
    private var lastCapCheck = 0L
    private var lastNotif = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { shutdown("Dihentikan"); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY

        createChannel()
        val n = buildNotification("Menyiapkan…")
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
        else intent?.getParcelableExtra("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        Prefs.load(this, cfg)
        brain = Brain(cfg)
        ocr = ScoreOcr(brain)

        thread = HandlerThread("laylabot").also { it.start() }
        handler = Handler(thread!!.looper)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { handler?.post { shutdown("Perekaman layar berhenti") } }
        }, handler)

        overlay = Overlay(this) { togglePause() }.also { it.show() }
        setupCapture()
        running = true
        lastMessage = "Berjalan"
        handler!!.post(loop)
        return START_NOT_STICKY
    }

    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val t0 = SystemClock.uptimeMillis()
            try { tick(t0) } catch (e: Throwable) { lastMessage = "Error: ${e.message}" }
            val dt = SystemClock.uptimeMillis() - t0
            handler?.postDelayed(this, max(1L, 40L - dt))
        }
    }

    private fun tick(now: Long) {
        if (now - lastCapCheck > 1000) { lastCapCheck = now; setupCapture() }
        val f = grab() ?: return
        val acc = BotAccessibilityService.instance
        if (paused) { overlay?.setText("Layla Bot ⏸ (ketuk untuk lanjut)"); return }
        if (acc == null) { overlay?.setText("Aktifkan Accessibility Layla Bot!"); return }

        val out = brain.step(f, now)
        ocr?.maybeRun(f, now)

        if (out.stopReason != null) {
            acc.release()
            vibrate()
            lastMessage = out.stopReason
            shutdown(out.stopReason)
            return
        }
        if (!out.inGame) acc.release()
        else {
            acc.setJoystick(out.dirX, out.dirY)
            if (out.ult) acc.tapUlt()
        }
        overlay?.setText("Layla Bot · ${out.status}")
        if (now - lastNotif > 3000) { lastNotif = now; notify(out.status) }
    }

    // ------------------------------------------------------------------ capture

    private fun setupCapture() {
        val dm = resources.displayMetrics
        val rw = dm.widthPixels; val rh = dm.heightPixels
        val scale = min(1f, 1280f / max(rw, rh))
        val cw = (rw * scale).toInt() and 1.inv()
        val ch = (rh * scale).toInt() and 1.inv()
        if (display != null && cw == capW && ch == capH) return
        val newReader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2)
        if (display == null) {
            display = projection!!.createVirtualDisplay(
                "laylabot", cw, ch, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                newReader.surface, null, handler
            )
        } else {
            display!!.resize(cw, ch, dm.densityDpi)
            display!!.surface = newReader.surface
        }
        reader?.close()
        reader = newReader
        capW = cw; capH = ch
        px = IntArray(cw * ch)
    }

    private fun grab(): Frame? {
        val img = reader?.acquireLatestImage() ?: return null
        try {
            val pl = img.planes[0]
            val ib = pl.buffer.order(ByteOrder.LITTLE_ENDIAN).asIntBuffer()
            val stride = pl.rowStride / 4
            for (y in 0 until capH) {
                ib.position(y * stride)
                ib.get(px, y * capW, min(capW, ib.remaining()))
            }
            return Frame(capW, capH, px, true)
        } finally { img.close() }
    }

    // ------------------------------------------------------------------ kontrol

    private fun togglePause() {
        paused = !paused
        if (paused) BotAccessibilityService.instance?.release() else brain.reset()
    }

    private fun vibrate() {
        val v = getSystemService(VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE))
    }

    private fun shutdown(msg: String) {
        if (!running && projection == null) { stopSelf(); return }
        running = false
        if (lastMessage.isEmpty() || lastMessage == "Berjalan") lastMessage = msg
        BotAccessibilityService.instance?.release()
        overlay?.hide(); overlay = null
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        display = null; reader = null; projection = null
        thread?.quitSafely(); thread = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { if (running) shutdown("Dihentikan"); super.onDestroy() }

    // ------------------------------------------------------------------ notifikasi

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Layla Bot", NotificationManager.IMPORTANCE_LOW))
    }

    private fun buildNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, BotService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
        ).build()
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("Layla Bot aktif")
            .setContentText(text)
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    private fun notify(text: String) {
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(1, buildNotification(text))
    }
}
