(async function (name, msgs) {
  const SEL = {
    chatItem: '[data-e2e="chat-list-item"]',
    input: '[data-e2e="message-input-area"] [contenteditable="true"], div[contenteditable="true"]',
    send: '[data-e2e="message-send"]'
  };
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  async function wait(fn, t) {
    const s = Date.now();
    while (Date.now() - s < t) { const v = fn(); if (v) return v; await sleep(300); }
    return null;
  }
  try {
    if (location.href.includes('login')) return Android.done(false, 'login');
    if (document.querySelector('[id*="captcha" i],[class*="captcha" i]')) return Android.done(false, 'captcha');

    const items = await wait(() => {
      const l = [...document.querySelectorAll(SEL.chatItem)];
      return l.length ? l : null;
    }, 20000);
    if (!items) return Android.done(false, 'daftar chat tidak ditemukan');

    const target = items.find(e => (e.innerText || '').toLowerCase().includes(name.toLowerCase()));
    if (!target) return Android.done(false, 'teman tidak ditemukan');
    target.click();
    await sleep(1800);

    for (const msg of msgs) {
      const input = await wait(() => document.querySelector(SEL.input), 10000);
      if (!input) return Android.done(false, 'kolom pesan tidak ditemukan');
      input.focus();
      document.execCommand('insertText', false, msg);
      input.dispatchEvent(new InputEvent('input', { bubbles: true }));
      await sleep(900);
      const btn = document.querySelector(SEL.send);
      if (btn) btn.click();
      else input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
      await sleep(2200);
    }
    Android.done(true, 'terkirim (' + msgs.length + ' pesan)');
  } catch (e) {
    Android.done(false, String(e));
  }
})(__NAME__, __MSGS__);
