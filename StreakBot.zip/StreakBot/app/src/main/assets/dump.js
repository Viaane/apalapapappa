(async function () {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const start = Date.now();
  let el = null;
  while (Date.now() - start < 20000) {
    el = document.querySelector('[data-e2e="chat-list-item"]');
    if (el) break;
    await sleep(300);
  }
  let out;
  if (!el) out = 'TIDAK ADA chat-list-item. URL=' + location.href + ' TEKS=' + document.body.innerText.slice(0, 600).replace(/\s+/g, ' ');
  else out = 'URL=' + location.href + ' ITEM=' + el.outerHTML.slice(0, 2500).replace(/\s+/g, ' ');
  Android.dump(out);
})();
