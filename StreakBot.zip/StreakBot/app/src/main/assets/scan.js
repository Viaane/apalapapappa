(async function () {
  const SEL = '[data-e2e="chat-list-item"]';
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  function getItems() {
    const l = [...document.querySelectorAll(SEL)];
    return l.filter(e => !l.some(o => o !== e && o.contains(e)));
  }
  function pickName(el, lines) {
    const n = el.querySelector('[data-e2e="chat-nickname"], [data-e2e*="nickname" i], [class*="Nickname" i], [class*="username" i]');
    if (n && (n.innerText || '').trim()) return n.innerText.trim().split('\n')[0];
    for (const l of lines) {
      if (/^[\d:\/\-\s.]+$/.test(l)) continue;
      return l;
    }
    return '';
  }
  try {
    if (location.href.includes('login')) return Android.scanDone('login', '[]');
    if (document.querySelector('[id*="captcha" i],[class*="captcha" i]')) return Android.scanDone('captcha', '[]');

    let items = [];
    const start = Date.now();
    while (Date.now() - start < 20000) { items = getItems(); if (items.length) break; await sleep(300); }
    if (!items.length) return Android.scanDone('daftar chat tidak ditemukan', '[]');

    for (let i = 0; i < 4; i++) {
      items[items.length - 1].scrollIntoView();
      await sleep(1200);
      const n = getItems();
      if (n.length <= items.length) break;
      items = n;
    }

    const out = [];
    const seen = new Set();
    for (const el of items) {
      const text = (el.innerText || '').trim();
      const lines = text.split('\n').map(s => s.replace(/🔥/g, '').trim()).filter(Boolean);
      const name = pickName(el, lines).replace(/🔥/g, '').trim();
      if (!name || seen.has(name.toLowerCase())) continue;
      seen.add(name.toLowerCase());

      const sEl = el.querySelector('[class*="streak" i], [data-e2e*="streak" i], img[alt*="streak" i], img[src*="streak" i]');
      let count = 0;
      let m = text.match(/🔥\s*(\d+)/) || text.match(/(\d+)\s*🔥/);
      if (m) count = parseInt(m[1], 10);
      else if (sEl) {
        const mm = ((sEl.innerText || sEl.alt || '') + '').match(/\d+/);
        if (mm) count = parseInt(mm[0], 10);
        else {
          const par = (sEl.parentElement && sEl.parentElement.innerText) || '';
          const m2 = par.match(/\d+/);
          if (m2) count = parseInt(m2[0], 10);
        }
      }
      const lit = !!sEl || /🔥/.test(text) || count > 0;
      out.push({ name: name, streak: count, lit: lit });
    }
    Android.scanDone('ok', JSON.stringify(out));
  } catch (e) {
    Android.scanDone(String(e), '[]');
  }
})();
