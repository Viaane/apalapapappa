package com.streakbot

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this); Log.init(this); Bot.init(this)
    }
}

data class Friend(
    val name: String, val avatar: String, val streak: Int, val active: Boolean,
    val lastSent: Long = 0, val lastResult: String = ""
)

object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("s", 0) }
    var message: String
        get() = sp.getString("msg", "🔥")!!
        set(v) = sp.edit().putString("msg", v).apply()
    var hours: Int
        get() = sp.getInt("h", 6)
        set(v) = sp.edit().putInt("h", v).apply()
    var auto: Boolean
        get() = sp.getBoolean("auto", false)
        set(v) = sp.edit().putBoolean("auto", v).apply()
    var lastRun: Long
        get() = sp.getLong("lr", 0)
        set(v) = sp.edit().putLong("lr", v).apply()
    var friends: List<Friend>
        get() = try {
            val a = JSONArray(sp.getString("fr", "[]"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Friend(o.getString("n"), o.optString("a"), o.optInt("s"), o.optBoolean("on"),
                    o.optLong("t"), o.optString("r"))
            }
        } catch (e: Exception) { emptyList() }
        set(v) {
            val a = JSONArray()
            v.forEach { a.put(JSONObject().put("n", it.name).put("a", it.avatar).put("s", it.streak)
                .put("on", it.active).put("t", it.lastSent).put("r", it.lastResult)) }
            sp.edit().putString("fr", a.toString()).apply()
        }
}

object Log {
    private lateinit var f: File
    private val fmt = SimpleDateFormat("dd/MM HH:mm:ss", Locale.getDefault())
    fun init(c: Context) { f = File(c.filesDir, "log.txt") }
    @Synchronized private fun w(level: String, m: String) {
        try {
            if (f.length() > 200_000) f.writeText(f.readText().takeLast(80_000))
            f.appendText("${fmt.format(Date())} [$level] $m\n")
        } catch (_: Exception) {}
    }
    fun i(m: String) = w("INFO", m)
    fun e(m: String) = w("ERROR", m)
    fun read(): String = try { f.readText() } catch (_: Exception) { "" }
    fun tail(n: Int): String = read().lines().filter { it.isNotBlank() }.takeLast(n).joinToString("\n")
    fun clear() { try { f.writeText("") } catch (_: Exception) {} }
}
