package com.streakbot

import android.app.Activity
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast

class LoginActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true }
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.userAgentString = UA
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        w.webViewClient = WebViewClient()
        w.loadUrl("https://www.tiktok.com/login")
        root.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val btn = Button(this).apply {
            text = "Selesai — saya sudah login"
            setOnClickListener {
                CookieManager.getInstance().flush()
                if (Bot.loggedIn()) { Log.i("Login TikTok berhasil"); finish() }
                else Toast.makeText(this@LoginActivity, "Login belum terdeteksi", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(btn)
        setContentView(root)
    }
}
