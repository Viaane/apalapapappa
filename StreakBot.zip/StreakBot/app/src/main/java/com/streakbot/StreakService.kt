package com.streakbot

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

/** mode: "send" (kirim streak), "scan" (deteksi api), "dump" (debug struktur halaman). */
class StreakService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var webView: WebView? = null
    private val queue = ArrayDeque<String>()
    private var mode = "send"
    private var running = false
    private var awaiting = false
    private var pageReady = false
    private var currentFriend = ""
    private var sent = 0
    private var failed = 0
    private var wakeLock: PowerManager.WakeLock? = null
    private val timeoutRunnable = Runnable { onResult(false, "timeout") }
    private val hardStop = Runnable {
        Prefs.log(this, "Timeout ($mode)")
        finishRun()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        ServiceCompat.startForeground(
            this, 1, notif("StreakBot berjalan…"),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        )
        if (running) return START_NOT_STICKY
        running = true
        mode = intent?.getStringExtra("mode") ?: "send"
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "streakbot:run")
            .apply { acquire(10 * 60 * 1000L) }

        if (mode == "send") {
            queue.addAll(Prefs.friends(this).filter { it.enabled }.map { it.name })
            if (queue.isEmpty()) {
                Prefs.log(this, "Tidak ada teman aktif. Scan dulu atau aktifkan teman.")
                finishRun()
                return START_NOT_STICKY
            }
            Prefs.log(this, "Mulai kirim ke ${queue.size} teman")
        } else {
            Prefs.log(this, if (mode == "scan") "Scan teman dimulai…" else "Dump struktur dimulai…")
            handler.postDelayed(hardStop, 90_000)
        }
        startWebView()
        return START_NOT_STICKY
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun startWebView() {
        val wv = WebView(applicationContext)
        webView = wv
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            userAgentString = Prefs.DESKTOP_UA
        }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.measure(
            View.MeasureSpec.makeMeasureSpec(1280, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(900, View.MeasureSpec.EXACTLY)
        )
        wv.layout(0, 0, 1280, 900)
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (pageReady) return
                pageReady = true
                handler.postDelayed({
                    when (mode) {
                        "scan" -> runAsset("scan.js")
                        "dump" -> runAsset("dump.js")
                        else -> next()
                    }
                }, 5000)
            }
        }
        CookieManager.getInstance().setAcceptCookie(true)
        wv.loadUrl("https://www.tiktok.com/messages")
    }

    private fun readAsset(n: String) = assets.open(n).bufferedReader().use { it.readText() }

    private fun runAsset(n: String) {
        webView?.evaluateJavascript(readAsset(n), null)
    }

    private fun next() {
        val friend = queue.removeFirstOrNull() ?: return finishRun()
        currentFriend = friend
        val msgs = JSONArray(Prefs.buildMessages(this))
        val js = readAsset("inject.js")
            .replace("__NAME__", JSONObject.quote(friend))
            .replace("__MSGS__", msgs.toString())
        awaiting = true
        handler.postDelayed(timeoutRunnable, 90_000)
        webView?.evaluateJavascript(js, null)
    }

    private fun onResult(ok: Boolean, info: String) {
        if (!awaiting) return
        awaiting = false
        handler.removeCallbacks(timeoutRunnable)
        if (ok) {
            sent++
            Prefs.markSent(this, currentFriend)
        } else failed++
        Prefs.log(this, (if (ok) "✓ " else "✗ ") + "$currentFriend: $info")
        if (info == "login" || info == "captcha") {
            Prefs.log(
                this,
                if (info == "login") "Sesi habis, login ulang di app"
                else "Captcha muncul, selesaikan manual lewat tombol Login"
            )
            return finishRun()
        }
        handler.postDelayed({ next() }, Random.nextLong(3000, 7000))
    }

    private fun onScan(status: String, json: String) {
        handler.removeCallbacks(hardStop)
        if (status != "ok") {
            Prefs.log(this, "Scan gagal: $status")
            return finishRun()
        }
        try {
            val arr = JSONArray(json)
            val old = Prefs.friends(this)
            val merged = ArrayList<Friend>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.getString("name")
                val lit = o.optBoolean("lit", false)
                val prev = old.find { it.name.equals(name, true) }
                merged.add(Friend(name, o.optInt("streak", 0), lit, prev?.enabled ?: lit, prev?.lastSent ?: 0L))
            }
            old.filter { f -> merged.none { it.name.equals(f.name, true) } }.forEach { merged.add(it) }
            Prefs.saveFriends(this, merged)
            Prefs.log(this, "Scan: ${arr.length()} chat, ${merged.count { it.lit }} api nyala")
        } catch (e: Exception) {
            Prefs.log(this, "Scan error: ${e.message}")
        }
        finishRun()
    }

    private fun onDump(s: String) {
        handler.removeCallbacks(hardStop)
        Prefs.setDump(this, s)
        Prefs.log(this, "Dump tersimpan (${s.length} karakter). Tekan 'Salin hasil dump'.")
        finishRun()
    }

    private fun finishRun() {
        handler.removeCallbacksAndMessages(null)
        webView?.let { CookieManager.getInstance().flush(); it.destroy() }
        webView = null
        if (mode == "send") {
            Prefs.log(this, "Selesai: $sent terkirim, $failed gagal")
            notifySummary("Streak: $sent terkirim, $failed gagal")
        }
        wakeLock?.let { if (it.isHeld) it.release() }
        running = false
        pageReady = false
        awaiting = false
        sent = 0
        failed = 0
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @SuppressLint("MissingPermission")
    private fun notifySummary(text: String) {
        try { NotificationManagerCompat.from(this).notify(2, notif(text)) } catch (_: Exception) {}
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
                NotificationChannel("streak", "StreakBot", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notif(text: String): Notification =
        Notification.Builder(this, "streak")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("StreakBot")
            .setContentText(text)
            .build()

    private inner class Bridge {
        @JavascriptInterface
        fun done(ok: Boolean, info: String) { handler.post { onResult(ok, info) } }

        @JavascriptInterface
        fun scanDone(status: String, json: String) { handler.post { onScan(status, json) } }

        @JavascriptInterface
        fun dump(s: String) { handler.post { onDump(s) } }
    }
}
