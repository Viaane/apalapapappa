package com.streakbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Friend(
    val name: String,
    val streak: Int,
    val lit: Boolean,
    val enabled: Boolean,
    val lastSent: Long
)

object Prefs {
    const val DESKTOP_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    private fun p(c: Context) = c.getSharedPreferences("streakbot", Context.MODE_PRIVATE)
    private fun lines(s: String) = s.lines().map { it.trim() }.filter { it.isNotEmpty() }

    // ---- pengaturan ----
    fun messagesRaw(c: Context) = p(c).getString("messages", "🔥") ?: "🔥"
    fun urlsRaw(c: Context) = p(c).getString("urls", "") ?: ""
    fun messages(c: Context) = lines(messagesRaw(c))
    fun urls(c: Context) = lines(urlsRaw(c))
    fun mode(c: Context) = p(c).getString("mode", "text") ?: "text"
    fun hour(c: Context) = p(c).getInt("hour", 8)
    fun minute(c: Context) = p(c).getInt("minute", 0)
    fun jitter(c: Context) = p(c).getInt("jitter", 10)
    fun enabled(c: Context) = p(c).getBoolean("enabled", false)

    fun saveSettings(
        c: Context, messages: String, urls: String, mode: String,
        hour: Int, minute: Int, jitter: Int, enabled: Boolean
    ) {
        p(c).edit()
            .putString("messages", messages).putString("urls", urls).putString("mode", mode)
            .putInt("hour", hour).putInt("minute", minute)
            .putInt("jitter", jitter).putBoolean("enabled", enabled)
            .apply()
    }

    /** Susunan pesan sekali kirim: teks acak dan/atau link video acak. */
    fun buildMessages(c: Context): List<String> {
        val out = ArrayList<String>()
        val m = mode(c)
        if (m != "video") messages(c).randomOrNull()?.let { out.add(it) }
        if (m != "text") urls(c).randomOrNull()?.let { out.add(it) }
        if (out.isEmpty()) out.add("🔥")
        return out
    }

    // ---- teman ----
    fun friendsJson(c: Context) = p(c).getString("friends_json", "[]") ?: "[]"

    fun friends(c: Context): List<Friend> = try {
        val a = JSONArray(friendsJson(c))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Friend(
                o.getString("name"), o.optInt("streak", 0), o.optBoolean("lit", false),
                o.optBoolean("enabled", true), o.optLong("lastSent", 0L)
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun saveFriends(c: Context, list: List<Friend>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("name", it.name).put("streak", it.streak).put("lit", it.lit)
                    .put("enabled", it.enabled).put("lastSent", it.lastSent)
            )
        }
        p(c).edit().putString("friends_json", a.toString()).apply()
    }

    fun addFriend(c: Context, name: String) {
        val l = friends(c)
        if (l.none { it.name.equals(name, true) }) saveFriends(c, l + Friend(name, 0, false, true, 0L))
    }

    fun removeFriend(c: Context, name: String) =
        saveFriends(c, friends(c).filter { it.name != name })

    fun setEnabled(c: Context, name: String, on: Boolean) =
        saveFriends(c, friends(c).map { if (it.name == name) it.copy(enabled = on) else it })

    fun markSent(c: Context, name: String) =
        saveFriends(c, friends(c).map {
            if (it.name == name) it.copy(lastSent = System.currentTimeMillis()) else it
        })

    // ---- debug & log ----
    fun setDump(c: Context, s: String) = p(c).edit().putString("dump", s).apply()
    fun dump(c: Context) = p(c).getString("dump", "") ?: ""

    fun log(c: Context, line: String) {
        val t = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
        val old = logText(c).lines().filter { it.isNotBlank() }
        p(c).edit().putString("log", (listOf("$t  $line") + old).take(40).joinToString("\n")).apply()
    }

    fun logText(c: Context) = p(c).getString("log", "") ?: ""
}
