package com.streakbot

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var friendsBox: LinearLayout
    private lateinit var addInput: EditText
    private lateinit var messages: EditText
    private lateinit var urls: EditText
    private lateinit var jitter: EditText
    private lateinit var enabled: Switch
    private lateinit var timeBtn: Button
    private lateinit var logView: TextView
    private lateinit var loginInfo: TextView
    private lateinit var modeBtns: List<Button>
    private var hour = 8
    private var minute = 0
    private var mode = "text"
    private var snapshot = ""
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            refresh(false)
            handler.postDelayed(this, 3000)
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun fmtTime() = "%02d:%02d".format(hour, minute)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0B14")
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        hour = Prefs.hour(this)
        minute = Prefs.minute(this)
        mode = Prefs.mode(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(28), dp(16), dp(32))

        root.addView(Ui.text(this, "🔥 StreakBot", 28f, Ui.WHITE, true))
        val sub = Ui.text(this, "Auto streak TikTok di latar belakang", 13f, Ui.MUTED)
        sub.setPadding(0, 0, 0, dp(16))
        root.addView(sub)

        // ---- Akun ----
        val acc = Ui.card(this)
        acc.addView(Ui.title(this, "AKUN"))
        loginInfo = Ui.text(this, "", 13f, Ui.MUTED)
        acc.addView(loginInfo)
        acc.addView(Ui.button(this, "Login TikTok", false) {
            startActivity(Intent(this, LoginActivity::class.java))
        })
        acc.addView(Ui.button(this, "🔍  Scan teman yang punya api", true) { runService("scan") })
        root.addView(acc)

        // ---- Teman ----
        val fc = Ui.card(this)
        fc.addView(Ui.title(this, "TEMAN STREAK"))
        friendsBox = LinearLayout(this)
        friendsBox.orientation = LinearLayout.VERTICAL
        fc.addView(friendsBox)
        fc.addView(Ui.text(this, "Tahan lama pada nama untuk menghapus.", 11f, Ui.MUTED))
        val addRow = LinearLayout(this)
        addRow.orientation = LinearLayout.HORIZONTAL
        addRow.gravity = Gravity.CENTER_VERTICAL
        addRow.setPadding(0, dp(10), 0, 0)
        addInput = Ui.input(this, "@username (tambah manual)", "")
        addRow.addView(addInput, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))
        val addBtn = Ui.button(this, "+", false) {
            val n = addInput.text.toString().trim().removePrefix("@")
            if (n.isNotEmpty()) {
                Prefs.addFriend(this, n)
                addInput.setText("")
                refresh(true)
            }
        }
        val addLp = LinearLayout.LayoutParams(dp(52), dp(48))
        addLp.leftMargin = dp(8)
        addBtn.layoutParams = addLp
        addRow.addView(addBtn)
        fc.addView(addRow)
        root.addView(fc)

        // ---- Pesan ----
        val mc = Ui.card(this)
        mc.addView(Ui.title(this, "ISI PESAN"))
        val modeRow = LinearLayout(this)
        modeRow.orientation = LinearLayout.HORIZONTAL
        modeBtns = listOf("text" to "Teks", "video" to "Video", "both" to "Teks + Video").map { (key, label) ->
            val b = Ui.button(this, label, false) {
                mode = key
                updateModes()
            }
            b.tag = key
            b.textSize = 12f
            val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
            lp.leftMargin = dp(3)
            lp.rightMargin = dp(3)
            b.layoutParams = lp
            modeRow.addView(b)
            b
        }
        mc.addView(modeRow)
        updateModes()

        val l1 = Ui.text(this, "Teks chat (satu per baris, dipilih acak)", 12f, Ui.MUTED)
        l1.setPadding(0, dp(12), 0, dp(4))
        mc.addView(l1)
        messages = Ui.input(this, "contoh: 🔥", Prefs.messagesRaw(this), 3)
        mc.addView(messages)

        val l2 = Ui.text(this, "Link video TikTok (satu per baris, dipilih acak)", 12f, Ui.MUTED)
        l2.setPadding(0, dp(12), 0, dp(4))
        mc.addView(l2)
        urls = Ui.input(this, "https://www.tiktok.com/@user/video/123…", Prefs.urlsRaw(this), 3)
        mc.addView(urls)
        mc.addView(Ui.text(this, "Link dikirim ke chat dan tampil sebagai kartu video, seperti share biasa.", 11f, Ui.MUTED))
        root.addView(mc)

        // ---- Jadwal ----
        val sc = Ui.card(this)
        sc.addView(Ui.title(this, "JADWAL"))
        timeBtn = Ui.button(this, fmtTime(), false) {
            TimePickerDialog(this, { _, h, m ->
                hour = h
                minute = m
                timeBtn.text = fmtTime()
            }, hour, minute, true).show()
        }
        sc.addView(Ui.text(this, "Jam kirim", 12f, Ui.MUTED))
        sc.addView(timeBtn)
        val l3 = Ui.text(this, "Jeda acak ± menit", 12f, Ui.MUTED)
        l3.setPadding(0, dp(10), 0, dp(4))
        sc.addView(l3)
        jitter = Ui.input(this, "10", Prefs.jitter(this).toString())
        jitter.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        sc.addView(jitter)
        enabled = Switch(this)
        enabled.text = "Aktifkan auto streak harian"
        enabled.setTextColor(Ui.WHITE)
        enabled.isChecked = Prefs.enabled(this)
        enabled.setPadding(0, dp(14), 0, dp(4))
        sc.addView(enabled)
        sc.addView(Ui.button(this, "💾  Simpan & jadwalkan", true) {
            saveForm()
            if (enabled.isChecked) Scheduler.schedule(this, false) else Scheduler.cancel(this)
            Toast.makeText(this, "Tersimpan", Toast.LENGTH_SHORT).show()
            refresh(true)
        })
        sc.addView(Ui.button(this, "🚀  Kirim sekarang (tes)", false) { runService("send") })
        sc.addView(Ui.button(this, "🔋  Izinkan tanpa optimasi baterai", false) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        root.addView(sc)

        // ---- Log ----
        val lc = Ui.card(this)
        lc.addView(Ui.title(this, "LOG"))
        logView = Ui.text(this, "", 11f, Ui.MUTED)
        logView.setTextIsSelectable(true)
        lc.addView(logView)
        lc.addView(Ui.button(this, "🧩  Dump struktur chat (debug)", false) { runService("dump") })
        lc.addView(Ui.button(this, "📋  Salin hasil dump", false) {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("dump", Prefs.dump(this)))
            Toast.makeText(this, "Disalin", Toast.LENGTH_SHORT).show()
        })
        root.addView(lc)

        val sv = ScrollView(this)
        sv.background = Ui.pageBackground()
        sv.isFillViewport = true
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    private fun updateModes() {
        modeBtns.forEach { b ->
            val sel = b.tag == mode
            b.background = if (sel) Ui.rounded(Ui.PINK, 14, this)
            else Ui.rounded(Color.parseColor("#26FFFFFF"), 14, this, Color.parseColor("#44FFFFFF"), 1)
        }
    }

    private fun saveForm() {
        val j = jitter.text.toString().toIntOrNull()?.coerceIn(0, 60) ?: 10
        Prefs.saveSettings(
            this, messages.text.toString(), urls.text.toString(), mode,
            hour, minute, j, enabled.isChecked
        )
    }

    private fun runService(m: String) {
        saveForm()
        ContextCompat.startForegroundService(this, Intent(this, StreakService::class.java).putExtra("mode", m))
        val msg = when (m) {
            "scan" -> "Scan berjalan di latar belakang…"
            "dump" -> "Mengambil struktur halaman…"
            else -> "Mengirim di latar belakang…"
        }
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun refresh(force: Boolean) {
        val fj = Prefs.friendsJson(this)
        if (force || fj != snapshot) {
            snapshot = fj
            renderFriends()
        }
        logView.text = Prefs.logText(this).ifEmpty { "(belum ada log)" }
        val ok = CookieManager.getInstance().getCookie("https://www.tiktok.com")?.contains("sessionid") == true
        loginInfo.text = if (ok) "✅ Sudah login TikTok" else "⚠️ Belum login. Tekan Login TikTok dulu."
    }

    private fun renderFriends() {
        friendsBox.removeAllViews()
        val list = Prefs.friends(this)
        if (list.isEmpty()) {
            friendsBox.addView(Ui.text(this, "Belum ada teman. Tekan Scan atau tambah manual.", 13f, Ui.MUTED))
            return
        }
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
        list.sortedWith(compareByDescending<Friend> { it.lit }.thenByDescending { it.streak })
            .forEach { friendsBox.addView(friendRow(it, fmt)) }
    }

    private fun friendRow(f: Friend, fmt: SimpleDateFormat): View {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        row.setOnLongClickListener {
            Prefs.removeFriend(this, f.name)
            refresh(true)
            Toast.makeText(this, "@${f.name} dihapus", Toast.LENGTH_SHORT).show()
            true
        }

        val palette = listOf("#FE2C55", "#25F4EE", "#7C4DFF", "#FF9100", "#00C853", "#2979FF")
        val colorHex = palette[(f.name.hashCode() and 0x7fffffff) % palette.size]
        row.addView(Ui.avatar(this, f.name.take(1).uppercase(), Color.parseColor(colorHex)))

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        mid.setPadding(dp(12), 0, dp(8), 0)
        mid.addView(Ui.text(this, "@" + f.name, 15f, Ui.WHITE, true))
        mid.addView(
            Ui.text(
                this,
                if (f.lastSent == 0L) "Belum dikirim bot" else "Dikirim " + fmt.format(Date(f.lastSent)),
                11f, Ui.MUTED
            )
        )
        row.addView(mid, LinearLayout.LayoutParams(0, Ui.WRAP, 1f))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.gravity = Gravity.END
        right.setPadding(0, 0, dp(8), 0)
        right.addView(
            if (f.lit) Ui.chip(this, "🔥 NYALA", Color.parseColor("#00E676"), Color.parseColor("#2600E676"))
            else Ui.chip(this, "💤 OFF", Color.parseColor("#BDBDBD"), Color.parseColor("#33FFFFFF"))
        )
        val pts = Ui.text(this, "${f.streak} poin", 12f, if (f.lit) Ui.WHITE else Ui.MUTED, true)
        pts.setPadding(0, dp(3), 0, 0)
        right.addView(pts)
        row.addView(right)

        val sw = Switch(this)
        sw.isChecked = f.enabled
        sw.setOnCheckedChangeListener { _, on -> Prefs.setEnabled(this, f.name, on) }
        row.addView(sw)
        return row
    }
}
