package com.streakbot

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import kotlinx.coroutines.launch
import android.webkit.CookieManager
import android.widget.*
import androidx.core.widget.doAfterTextChanged
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val cache = HashMap<String, Bitmap>()
    private lateinit var tvStatus: TextView
    private lateinit var tvLogin: TextView
    private lateinit var tvHours: TextView
    private lateinit var tvLog: TextView
    private lateinit var tvCount: TextView
    private lateinit var box: LinearLayout
    private val BLUE = 0xFF007AFF.toInt()
    private val GRAY = 0xFF8E8E93.toInt()
    private val RED = 0xFFFF3B30.toInt()
    private val GREEN = 0xFF34C759.toInt()
    private val BLACK = 0xFF000000.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun tv(t: String, size: Float = 17f, color: Int = BLACK, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun lp(w: Int = -1, hh: Int = -2, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, hh).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    private fun section(p: LinearLayout, t: String): TextView {
        val v = tv(t.uppercase(), 13f, GRAY).apply { setPadding(dp(16), 0, 0, dp(6)) }
        p.addView(v); return v
    }
    private fun card(p: LinearLayout): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(0xFFFFFFFF.toInt(), 14) }
        p.addView(c, lp(bottom = 22)); return c
    }
    private fun divider(c: LinearLayout) {
        if (c.childCount > 0) c.addView(View(this).apply { setBackgroundColor(0xFFE5E5EA.toInt()) },
            lp(-1, 1).apply { leftMargin = dp(16) })
    }
    private fun action(c: LinearLayout, t: String, color: Int = BLUE, onClick: () -> Unit) {
        divider(c)
        c.addView(tv(t, 17f, color).apply { setPadding(dp(16), dp(13), dp(16), dp(13)); setOnClickListener { onClick() } })
    }
    private fun row(c: LinearLayout, label: String, right: View) {
        divider(c)
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(11), dp(16), dp(11)) }
        r.addView(tv(label), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(right); c.addView(r)
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun ago(t: Long) = if (t == 0L) "belum pernah" else SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(t))

    private fun startSvc() = startForegroundService(Intent(this, BotService::class.java))

    private fun askBattery() {
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) toast("Sudah diizinkan berjalan di latar belakang")
        else startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFFF2F2F7.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val sv = ScrollView(this).apply { setBackgroundColor(0xFFF2F2F7.toInt()); fitsSystemWindows = true }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(40)) }
        sv.addView(root); setContentView(sv)

        root.addView(tv("Streak Bot", 34f, BLACK, true))
        tvStatus = tv("", 15f, GRAY); root.addView(tvStatus, lp(bottom = 18))

        section(root, "Akun")
        val ca = card(root)
        tvLogin = tv("", 17f, GRAY)
        row(ca, "TikTok", tvLogin)
        action(ca, "Masuk ke TikTok") { startActivity(Intent(this, LoginActivity::class.java)) }
        action(ca, "Keluar", RED) {
            CookieManager.getInstance().removeAllCookies(null); Store.friends = emptyList(); Log.i("Logout"); toast("Keluar")
        }

        tvCount = section(root, "Api streak")
        val cf = card(root)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cf.addView(box)
        action(cf, "Pindai Streak") { toast("Memindai… lihat status"); Bot.scope.launch { Bot.scan() } }

        section(root, "Auto chat")
        val cs = card(root)
        val sw = Switch(this).apply {
            isChecked = Store.auto
            setOnCheckedChangeListener { _, on ->
                Store.auto = on
                if (on) { Store.lastRun = System.currentTimeMillis(); startSvc(); askBattery() }
                else stopService(Intent(this@MainActivity, BotService::class.java))
            }
        }
        row(cs, "Aktif setiap hari", sw)
        tvHours = tv("", 17f, GRAY)
        val stepper = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val minus = tv("−", 26f, BLUE).apply { setPadding(dp(14), 0, dp(14), 0); setOnClickListener { Store.hours = maxOf(1, Store.hours - 1); refresh(false) } }
        val plus = tv("+", 26f, BLUE).apply { setPadding(dp(14), 0, dp(4), 0); setOnClickListener { Store.hours = minOf(24, Store.hours + 1); refresh(false) } }
        stepper.addView(tvHours); stepper.addView(minus); stepper.addView(plus)
        row(cs, "Kirim setiap", stepper)
        val et = EditText(this).apply {
            setText(Store.message); hint = "Isi pesan"; background = null; textSize = 17f
            setPadding(dp(16), dp(12), dp(16), dp(12))
            doAfterTextChanged { Store.message = it.toString() }
        }
        divider(cs); cs.addView(et)
        action(cs, "Tes kirim chat sekarang") { toast("Tes dimulai, lihat status & log"); Bot.sendAll(true) }
        action(cs, "Izinkan tetap berjalan (baterai)") { askBattery() }

        section(root, "Log")
        val cl = card(root)
        tvLog = tv("", 11f, 0xFF3C3C43.toInt()).apply { typeface = Typeface.MONOSPACE; setPadding(dp(16), dp(12), dp(16), dp(12)); setTextIsSelectable(true) }
        cl.addView(tvLog)
        action(cl, "Bagikan log") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, Log.read().takeLast(9000)), "Bagikan log"))
        }
        action(cl, "Hapus log", RED) { Log.clear(); refresh(false) }
        refresh(true)
    }

    private fun friendRow(f: Friend): View {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(10)) }
        val img = ImageView(this).apply { background = bg(0xFFE5E5EA.toInt(), 22); clipToOutline = true; scaleType = ImageView.ScaleType.CENTER_CROP }
        r.addView(img, LinearLayout.LayoutParams(dp(44), dp(44)))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0) }
        col.addView(tv(f.name, 17f, BLACK, true))
        col.addView(tv("🔥 ${f.streak} · " + if (f.active) "Menyala" else "Padam", 14f, if (f.active) GREEN else RED))
        col.addView(tv("Kirim terakhir: ${ago(f.lastSent)}" + if (f.lastResult.isNotEmpty()) " · ${f.lastResult}" else "", 12f, GRAY))
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (f.avatar.isNotEmpty()) {
            val c = cache[f.avatar]
            if (c != null) img.setImageBitmap(c) else Thread {
                try {
                    val cn = URL(f.avatar).openConnection() as HttpURLConnection
                    cn.setRequestProperty("User-Agent", UA); cn.setRequestProperty("Referer", "https://www.tiktok.com/")
                    val bm = BitmapFactory.decodeStream(cn.inputStream)
                    if (bm != null) { cache[f.avatar] = bm; h.post { img.setImageBitmap(bm) } }
                } catch (e: Exception) { Log.e("Gagal muat foto ${f.name}: $e") }
            }.start()
        }
        return r
    }

    private fun refresh(loop: Boolean) {
        tvStatus.text = Bot.status
        tvLogin.text = if (Bot.loggedIn()) "Masuk" else "Belum masuk"
        tvLogin.setTextColor(if (Bot.loggedIn()) GREEN else GRAY)
        tvHours.text = "${Store.hours} jam"
        val fr = Store.friends
        tvCount.text = "API STREAK (${fr.size})"
        box.removeAllViews()
        if (fr.isEmpty()) box.addView(tv("Belum ada data. Login lalu tekan Pindai Streak.", 15f, GRAY).apply { setPadding(dp(16), dp(14), dp(16), dp(14)) })
        else fr.forEachIndexed { i, f -> if (i > 0) divider(box); box.addView(friendRow(f)) }
        tvLog.text = Log.tail(30).ifEmpty { "(log kosong)" }
        if (loop) h.postDelayed({ refresh(true) }, 2500)
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); super.onDestroy() }
}
