package com.streakbot

import android.content.Context
import android.os.PowerManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

object Bot {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mutex = Mutex()
    @Volatile var status = "Siap"
    private lateinit var app: Context
    private var wv: WebView? = null
    private var pending: CompletableDeferred<Unit>? = null

    private const val URL_MSG = "https://www.tiktok.com/messages"
    // Selector item daftar chat. Ini TEBAKAN; kalau tidak cocok, log akan memuat dump HTML.
    private const val SEL = """[data-e2e*="chat-list-item"],[data-e2e*="conversation"],[class*="DivChatItem"],[class*="ConversationItem"]"""

    private val SCAN_JS = """(function(){
      var items=document.querySelectorAll('$SEL'); var out=[];
      items.forEach(function(el,i){
        var t=(el.innerText||'').trim(); if(!t) return;
        var lines=t.split('\n').map(function(s){return s.trim()}).filter(Boolean);
        var img=el.querySelector('img');
        var m=t.match(/🔥\s*(\d+)|(\d+)\s*🔥/);
        var fl=el.querySelector('[class*="treak"],[class*="Flame"],[data-e2e*="streak"]');
        var streak=m?parseInt(m[1]||m[2]):0; var active=!!m;
        if(fl){var s=getComputedStyle(fl); if(parseFloat(s.opacity)<1||(s.filter||'').indexOf('grayscale')>=0) active=false;}
        out.push({name:lines[0],avatar:img?img.src:'',streak:streak,active:active,has:(!!m||!!fl)});
      });
      return JSON.stringify(out);})()"""

    private fun typeJs(msg: String) = """(function(msg){
      var b=document.querySelector('[contenteditable="true"]')||document.querySelector('div[role="textbox"]');
      if(!b) return 'nobox'; b.focus(); document.execCommand('insertText',false,msg);
      b.dispatchEvent(new InputEvent('input',{bubbles:true})); return 'typed';})(${JSONObject.quote(msg)})"""

    private val SEND_JS = """(function(){
      var btn=document.querySelector('[data-e2e*="send"]');
      if(btn){btn.click();return 'clicked';}
      var b=document.querySelector('[contenteditable="true"]')||document.querySelector('div[role="textbox"]');
      if(!b) return 'nobox';
      ['keydown','keypress','keyup'].forEach(function(t){
        b.dispatchEvent(new KeyboardEvent(t,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));});
      return 'enter';})()"""

    private val EMPTY_JS = """(function(){var b=document.querySelector('[contenteditable="true"]')||document.querySelector('div[role="textbox"]');
      return (b&&(b.innerText||'').trim()==='')?'empty':'filled';})()"""

    fun init(c: Context) {
        app = c.applicationContext
        CookieManager.getInstance().setAcceptCookie(true)
    }

    fun loggedIn() = CookieManager.getInstance().getCookie("https://www.tiktok.com")?.contains("sessionid") == true

    private fun web(): WebView {
        wv?.let { return it }
        val w = WebView(app)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.userAgentString = UA
        w.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView?, u: String?) { pending?.complete(Unit) }
        }
        w.measure(android.view.View.MeasureSpec.makeMeasureSpec(1280, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(900, android.view.View.MeasureSpec.EXACTLY))
        w.layout(0, 0, 1280, 900)
        wv = w
        return w
    }

    private suspend fun load(url: String) {
        val d = CompletableDeferred<Unit>(); pending = d
        web().loadUrl(url)
        if (withTimeoutOrNull(30_000) { d.await() } == null) Log.e("Timeout memuat $url")
    }

    private suspend fun js(code: String): String = suspendCoroutine { c ->
        web().evaluateJavascript(code) { r ->
            val s = if (r == null || r == "null") "" else try { (JSONTokener(r).nextValue() as? String) ?: r } catch (e: Exception) { r }
            c.resume(s)
        }
    }

    private suspend fun dump(why: String) {
        val url = js("location.href")
        val txt = js("document.body.innerText.slice(0,600)")
        val html = js("(document.querySelector('$SEL')||document.body).outerHTML.slice(0,1800)")
        Log.e("DUMP ($why)\nURL: $url\nTEKS: $txt\nHTML: $html")
    }

    suspend fun scan(): Boolean = mutex.withLock { scanInner() }

    private suspend fun scanInner(): Boolean {
        if (!loggedIn()) { Log.e("Belum login TikTok"); status = "Belum login"; return false }
        status = "Memindai streak…"; Log.i("Mulai pindai streak")
        return try {
            load(URL_MSG); delay(9000)
            val raw = js(SCAN_JS)
            val arr = try { JSONArray(raw) } catch (e: Exception) {
                Log.e("Hasil JS tidak valid: '$raw'"); dump("scan"); status = "Gagal memindai"; return false
            }
            val old = Store.friends.associateBy { it.name }
            val found = ArrayList<Friend>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (!o.optBoolean("has")) continue
                val n = o.getString("name")
                found.add(Friend(n, o.optString("avatar"), o.optInt("streak"), o.optBoolean("active"),
                    old[n]?.lastSent ?: 0, old[n]?.lastResult ?: ""))
            }
            Log.i("Pindai selesai: ${arr.length()} chat, ${found.size} punya streak")
            if (found.isEmpty()) dump("tidak ada streak terdeteksi")
            else Store.friends = found
            status = "Ditemukan ${found.size} streak"
            found.isNotEmpty()
        } catch (e: Exception) {
            Log.e("Error pindai: ${e}"); status = "Error"; false
        }
    }

    private suspend fun sendOne(f: Friend, msg: String): String {
        load(URL_MSG); delay(8000)
        val q = JSONObject.quote(f.name)
        val c = js("(function(n){var it=document.querySelectorAll('$SEL');for(var i=0;i<it.length;i++){var l=(it[i].innerText||'').trim().split('\\n')[0].trim();if(l===n){it[i].click();return 'ok';}}return 'notfound';})($q)")
        if (c != "ok") { dump("chat ${f.name} tidak ditemukan"); return "gagal: chat tidak ditemukan ($c)" }
        delay(3500)
        val t = js(typeJs(msg))
        if (t != "typed") { dump("kotak chat"); return "gagal: kotak chat ($t)" }
        delay(800)
        val s = js(SEND_JS)
        delay(2000)
        val e = js(EMPTY_JS)
        return if (e == "empty") "terkirim ($s)" else { dump("kotak masih terisi setelah kirim"); "gagal: pesan belum terkirim ($s/$e)" }
    }

    fun sendAll(test: Boolean = false) { scope.launch { runSend(test) } }

    suspend fun runSend(test: Boolean) {
        mutex.withLock {
            val pm = app.getSystemService(PowerManager::class.java)
            val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "streakbot:run")
            wl.acquire(15 * 60 * 1000L)
            try {
                Log.i(if (test) "TES kirim chat dimulai" else "Auto chat dimulai")
                if (!loggedIn()) { Log.e("Belum login TikTok"); status = "Belum login"; return@withLock }
                if (Store.friends.isEmpty()) scanInner()
                val list = Store.friends
                if (list.isEmpty()) { Log.e("Tidak ada streak untuk dikirimi"); status = "Tidak ada target"; return@withLock }
                val msg = Store.message
                var ok = 0
                for (f in list) {
                    status = "Mengirim ke ${f.name}…"
                    val r = try { sendOne(f, msg) } catch (e: Exception) { "gagal: $e" }
                    if (r.startsWith("terkirim")) { ok++; Log.i("${f.name}: $r") } else Log.e("${f.name}: $r")
                    Store.friends = Store.friends.map {
                        if (it.name == f.name) it.copy(lastSent = System.currentTimeMillis(), lastResult = r) else it
                    }
                    delay(4000)
                }
                status = "Selesai: $ok/${list.size} terkirim"; Log.i(status)
            } catch (e: Exception) {
                Log.e("Error kirim: $e"); status = "Error"
            } finally { if (wl.isHeld) wl.release() }
        }
    }
}
