package com.streakbot

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*

class BotService : Service() {
    private var job: Job? = null
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Streak Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot").setContentTitle("Streak Bot aktif")
            .setContentText("Auto chat berjalan di latar belakang")
            .setSmallIcon(android.R.drawable.ic_dialog_info).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        if (job?.isActive != true) job = Bot.scope.launch {
            Log.i("Layanan latar belakang dimulai")
            while (isActive) {
                if (Store.auto && System.currentTimeMillis() - Store.lastRun >= Store.hours * 3_600_000L) {
                    Store.lastRun = System.currentTimeMillis()
                    Bot.runSend(false)
                }
                delay(30_000)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() { job?.cancel(); Log.i("Layanan dihentikan"); super.onDestroy() }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Store.auto) c.startForegroundService(Intent(c, BotService::class.java))
    }
}
