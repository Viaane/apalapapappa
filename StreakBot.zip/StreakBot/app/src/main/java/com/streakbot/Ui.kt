package com.streakbot

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    val PINK = Color.parseColor("#FE2C55")
    val CYAN = Color.parseColor("#25F4EE")
    val WHITE = Color.WHITE
    val MUTED = Color.parseColor("#B3FFFFFF")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, radiusDp: Int, c: Context, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(c, radiusDp).toFloat()
        if (strokeDp > 0) d.setStroke(dp(c, strokeDp), strokeColor)
        return d
    }

    fun pageBackground() = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(Color.parseColor("#0B0B14"), Color.parseColor("#1C0B33"), Color.parseColor("#400A45"))
    )

    fun card(c: Context): LinearLayout {
        val l = LinearLayout(c)
        l.orientation = LinearLayout.VERTICAL
        l.background = rounded(Color.parseColor("#26FFFFFF"), 20, c, Color.parseColor("#33FFFFFF"), 1)
        l.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 16))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(c, 14)
        l.layoutParams = lp
        return l
    }

    fun text(c: Context, t: String, size: Float = 14f, color: Int = WHITE, bold: Boolean = false): TextView {
        val v = TextView(c)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(null, Typeface.BOLD)
        return v
    }

    fun title(c: Context, t: String): TextView {
        val v = text(c, t, 12f, CYAN, true)
        v.letterSpacing = 0.1f
        v.setPadding(0, 0, 0, dp(c, 8))
        return v
    }

    fun button(c: Context, label: String, primary: Boolean, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(WHITE)
        b.textSize = 14f
        b.stateListAnimator = null
        b.background = if (primary) rounded(PINK, 14, c)
        else rounded(Color.parseColor("#26FFFFFF"), 14, c, Color.parseColor("#44FFFFFF"), 1)
        val lp = LinearLayout.LayoutParams(MATCH, dp(c, 48))
        lp.topMargin = dp(c, 8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    fun input(c: Context, hintText: String, value: String, rows: Int = 1): EditText {
        val e = EditText(c)
        e.setText(value)
        e.hint = hintText
        e.setTextColor(WHITE)
        e.setHintTextColor(Color.parseColor("#80FFFFFF"))
        e.textSize = 14f
        e.background = rounded(Color.parseColor("#1AFFFFFF"), 12, c, Color.parseColor("#33FFFFFF"), 1)
        e.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
        if (rows > 1) {
            e.minLines = rows
            e.gravity = Gravity.TOP
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        } else {
            e.isSingleLine = true
        }
        return e
    }

    fun chip(c: Context, label: String, fg: Int, bg: Int): TextView {
        val v = text(c, label, 11f, fg, true)
        v.background = rounded(bg, 10, c)
        v.setPadding(dp(c, 8), dp(c, 3), dp(c, 8), dp(c, 3))
        return v
    }

    fun avatar(c: Context, letter: String, color: Int): TextView {
        val v = text(c, letter, 18f, WHITE, true)
        v.gravity = Gravity.CENTER
        val d = GradientDrawable()
        d.setShape(GradientDrawable.OVAL)
        d.setColor(color)
        v.background = d
        v.layoutParams = LinearLayout.LayoutParams(dp(c, 44), dp(c, 44))
        return v
    }
}
